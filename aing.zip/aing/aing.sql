-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 29 Jun 2022 pada 22.59
-- Versi server: 10.4.17-MariaDB
-- Versi PHP: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aing`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('ferdinand', 'admin');

-- --------------------------------------------------------

--
-- Struktur dari tabel `table_index`
--

CREATE TABLE `table_index` (
  `NIK_Ktp` varchar(20) NOT NULL,
  `Nama` text NOT NULL,
  `Tempat_tanggallahir` varchar(30) NOT NULL,
  `Jenis_kelamin` varchar(15) NOT NULL,
  `Golongan_darah` varchar(5) NOT NULL,
  `Alamat` varchar(40) NOT NULL,
  `Nohp_wa` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `table_index`
--

INSERT INTO `table_index` (`NIK_Ktp`, `Nama`, `Tempat_tanggallahir`, `Jenis_kelamin`, `Golongan_darah`, `Alamat`, `Nohp_wa`) VALUES
('3276088349212294', 'Ferdinand Adhylla Mulky', 'Jakarta,31 Maret 2001', 'Laki-laki', 'B', 'Maluku, Jln Soetomo no.32', '081224210167'),
('123421', 'wfwfwf', '2eeee', 'p', 'a', 'sdefrfgt', '4444'),
('123456789', 'Risna Khoerunnisa', 'Bandung, 20 Mei 2002', 'p', 'o', 'Bandung', '085795171761'),
('9999999999999', 'Rani Rantika', '22/11/2000', 'p', 'AB', 'bandung', '9999999'),
('6666666666666666666', 'justin', '1994', 'L', 'O', 'usa', '999999999');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

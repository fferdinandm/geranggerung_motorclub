<?php
class database{
    var $host = "localhost";
    var $username = "root";
    var $password = "";
    var $database = "aing";
    var $koneksi = "";
    function __construct(){
        $this->koneksi = mysqli_connect($this->host, $this->username, $this->password, $this->database);
        if (mysqli_connect_errno()){
            echo "Koneksi Database Gagal :" . mysqli_connect_error();
        }
    }
    function tampil_data()
    {
        $data = mysqli_query($this->koneksi,"select * from table_index");
        while($row = mysqli_fetch_array($data)){
            $hasil[] = $row;
        }
        return $hasil;

    }
    function hitung_data()
    {
        $data = mysqli_query($this->koneksi,"select * from table_index");
        while($row = mysqli_fetch_array($data)){
            $hasil[] = $row;
        }
        $conn = count($hasil);
        echo $conn;

    }

   
    function tambah_data($NIK_Ktp, $Nama, $Tempat_tanggallahir, $Jenis_kelamin, $Golongan_darah, $Alamat, $Nohp_wa)
    {
        mysqli_query($this->koneksi,"insert into table_index values ('$NIK_Ktp', '$Nama', '$Tempat_tanggallahir', '$Jenis_kelamin', '$Golongan_darah', '$Alamat', '$Nohp_wa')");
    }
    








    

    /*Edit Data Mobil*/
    function get_by_id($id)
    {
        $query = mysqli_query($this->koneksi, "select * from stok_mobil where ID_Mobil='$id'");
    }
    function update_mobil($ID_Mobil, $Nama_mobil, $Merk, $Katogeri, $Tahun_Produksi)
    {
        $query = mysqli_query($this->koneksi, "update stok_Mobil set ID_Mobil='$ID_Mobil', Nama_mobil='$Nama_mobil',Merk='$Merk', Katogeri='$Katogeri', Tahun_Produksi='$Tahun_Produksi where ID_Mobil='$ID_Mobil'");
    }

    /*Hapus Data Mobil*/
    function delete_mobil($ID_Mobil)
    {
        $query = mysqli_query($this->koneksi, "delete from stok_mobilwhere ID_Mobil='$ID_Mobil'");
    }
    
}
?>        

    
<?php
include('database.php');
$koneksi = new database();

$action = $_GET['action'];
if($action =="add")
{
    $koneksi->tambah_data($_POST['nik'],$_POST['nama'],$_POST['tempat'],$_POST['jenis_kelamin'],$_POST['golongan_darah'],$_POST['alamat'],$_POST['nohp/wa']);
    header('location:../index.php');

}
?>

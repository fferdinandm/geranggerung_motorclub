<?php
include('database.php');
$db = new database();
$ID_Mobil = $_GET['ID_Mobil=='];

if(! is_nan($ID_Mobil))
{
	$data_mobil = $db->get_by_id($ID_Mobil);
} else {
	header('location:index.php');
}
?>
 <!DOCTYPE html>
 <html>
 	<head></head>
 	<body>
 		<div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-8">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Input Mobil Baru</h4>
                </div>
                <div class="card-body">
                  <form method="post" action ="inputdata.php?action=update1" >
                 
                      <div>
                        <div class="form-group">
                          <label class="bmd-label-floating">ID Mobil</label>
                          <input type="text" class="form-control" name="id" value="<?php echo $data_mobil['id'] ?>"  required>
                        </div>
                      </div>
                      
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Nama Mobil</label>
                          <input type="text" class="form-control" name="nama" value="<?php echo $data_mobil['nama']; ?>"  required>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Merk</label>
                          <input type="text" class="form-control" name="merk" value="<?php echo $data_mobil['merk']; ?>"  required>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Kategori</label>
                          <input type="text" class="form-control" name="kategori" value="<?php echo $data_mobil['kategori']; ?>"  required>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Tahun produksi </label>
                          <input type="text" class="form-control" name="produksi" value="<?php echo $data_mobil['produksi']; ?>"  required>
                        </div>
                      </div>
                      </div>
                  
                    <button type="submit" class="btn btn-primary pull-right" name="submit" value="submit">Update</button>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>
        </div>
      </div>
 	</body>
 </html>
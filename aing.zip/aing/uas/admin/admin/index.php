<html>
<head>
    <title>Showroom FAM | Admin Sign In</title>
    <link rel="icon" href="img/favicon.png" type="image/png">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        .b {
            background-size: cover;
        }
    </style>
</head>

<body style="background: url(../image/wallpaper.jpg); background-size: cover;" class="trans">
    <div class="white-text" style="padding-top: 100px;">
        <center>
        <li class="scroll-to-section"><a href="../../index.php" class="active">back</a></li>
        <div class="row">
      <div class="col-10 col-sm-8 col-md-6 col-lg-5 col-xl-4 mx-auto">
        <div class="card">
          <div class="card-header">
            <h4>Account Login</h4>
          </div>
          <div class="card-body">
            <form method="post" autocomplete="off" action="../index.php" >
              <div class="form-group">
                <label for="username">Username</label>
                <input type="username" class="form-control" name="username">
              </div>
              <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" name="password">
              </div>
              <input type="submit" class="btn btn-info btn-block"
              value="Login">
            </form>
          </div>
        </div>
      </div>
        </center>
    </div>
    <script src="js/jquery-3.3.1.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.js"></script>
</body>
</html>
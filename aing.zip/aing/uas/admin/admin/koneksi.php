<?php 
	$host = "localhost";
	$username = "root";
	$password = "";
	$db = "club_motor1";
	$conn = mysqli_connect($_host, $username, $password, $db) or die ("gagal!");
 ?>
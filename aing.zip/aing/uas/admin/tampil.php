<?php
    include 'database.php';
    $db = new database();
    ?>

    <h1> Stok kendaraan </h1>
    <h2>Crud OOP Php </h2>

    
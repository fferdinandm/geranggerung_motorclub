<?php
include 'database.php';
    $db = new database();
?>

<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@400;500;600;700&display=swap" rel="stylesheet">

    <title>GerangGerung Motorclub</title>
<!--
    
TemplateMo 558 Klassy Cafe

https://templatemo.com/tm-558-klassy-cafe

-->
    <!-- Additional CSS Files -->
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">

    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.css">

    <link rel="stylesheet" href="assets/css/templatemo-klassy-cafe.css">

    <link rel="stylesheet" href="assets/css/owl-carousel.css">

    <link rel="stylesheet" href="assets/css/lightbox.css">

    <style>
        .card1 {
  background-image: url(assets/images/cfbandung.jpg);
}
.card2 {
  background-image: url(assets/images/cfbali.jpg);
}
.card3 {
  background-image: url(assets/images/cfjogja.jpg);
}
.card4 {
  background-image: url(assets/images/cfjakarta.jpg);
}
.card5 {
  background-image: url(assets/images/cfbanten.jpg);
}
    </style>
    </head>
    
    <body>
    
    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    <!-- ***** Preloader End ***** -->
    
    
    <!-- ***** Header Area Start ***** -->
    <header class="header-area header-sticky">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav class="main-nav">
                        <!-- ***** Logo Start ***** -->
                        <a href="index.html" class="logo">
                            <img src="assets/images/geranggerung.png" align="geranggerung">
                        </a>
                        <!-- ***** Logo End ***** -->
                        <!-- ***** Menu Start ***** -->
                        <ul class="nav">
                            <li class="scroll-to-section"><a href="#top" class="active">Home</a></li>
                            <li class="scroll-to-section"><a href="#about">About</a></li>
                           	
                        <!-- 
                            <li class="submenu">
                                <a href="javascript:;">Drop Down</a>
                                <ul>
                                    <li><a href="#">Drop Down Page 1</a></li>
                                    <li><a href="#">Drop Down Page 2</a></li>
                                    <li><a href="#">Drop Down Page 3</a></li>
                                </ul>
                            </li>
                        -->
                            <li class="scroll-to-section"><a href="#menu">Photograph</a></li>
                            <!-- <li class=""><a rel="sponsored" href="https://templatemo.com" target="_blank">External URL</a></li> -->
                            <li class="scroll-to-section"><a href="#reservation">Kontak Admin</a></li>
                            <li class="scroll-to-section">
                                <a href="admin/./admin/index.php">Masuk admin</a>
                                <!-- <ul>
                                    <li><a href="admin/./admin/login.php">Login</a></li>  
                        </ul> -->
                        </li>        
                        <a class='menu-trigger'>
                            <span>Menu</span>
                        </a>
                        <!-- ***** Menu End ***** -->
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- ***** Header Area End ***** -->

    <!-- ***** Main Banner Area Start ***** -->
    <div id="top">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-4">
                    <div class="left-content">
                        <div class="inner-content">
                            <h4>Gerang Gerung</h4>
                            <h6>Ride or Die</h6>
                            <div class="main-white-button scroll-to-section">
                                <a href="input_anggota.php">Daftar Anggota</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="main-banner header-text">
                        <div class="Modern-Slider">
                          <!-- Item -->
                          <div class="item">
                            <div class="img-fill">
                                <img src="assets/images/touring1.jpg" alt="">
                            </div>
                          </div>
                          <!-- // Item -->
                          <!-- Item -->
                          <div class="item">
                            <div class="img-fill">
                                <img src="assets/images/touring2.jpg" alt="">
                            </div>
                          </div>
                          <!-- // Item -->
                          <!-- Item -->
                          <div class="item">
                            <div class="img-fill">
                                <img src="assets/images/touring3.jpg" alt="">
                            </div>
                          </div>
                          <!-- // Item -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ***** Main Banner Area End ***** -->

    <!-- ***** About Area Starts ***** -->
    <section class="section" id="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-xs-12">
                    <div class="left-text-content">
                        <div class="section-heading">
                            <h6>About Us</h6>
                            <h2>Explore the world with us</h2>
                        </div>
                        <p>GerangGerung is cafe racer biker community. It was discovered in 2015.It has approximate 87 active members. Come join us and feel the bond of family you never found </p>
                        <div class="row">
                            <div class="col-4">
                                <img src="assets/images/moto1.jpg" alt="">
                            </div>
                            <div class="col-4">
                                <img src="assets/images/moto2.jpg" alt="">
                            </div>
                            <div class="col-4">
                                <img src="assets/images/moto3.jpg" alt="">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-xs-12">
                    <div class="right-content">
                        <div class="thumb">
                            <a rel="nofollow" href="https://youtu.be/cgVxOjmeJ3c"><i class="fa fa-play"></i></a>
                            <img src="assets/images/touring1.jpg" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** About Area Ends ***** -->

    <!-- ***** Menu Area Starts ***** -->
    <section class="section" id="menu">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="section-heading">
                        <h6>Our Photograph</h6>
                        <h2>Pride Indonesia. JASMERAH!!!</h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="menu-item-carousel">
            <div class="col-lg-12">
                <div class="owl-menu-item owl-carousel">
                    <div class="item">
                        <div class='card card1'>
                            <div class="price"><h6>2015</h6></div>
                            <div class='info'>
                              <h1 class='title'>Chapter Bandung</h1>
                              <p class='description'>Awal mula touring dari komunitas ini</p>
                              <div class="main-text-button">
                              </div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class='card card2'>
                            <div class="price"><h6>2016</h6></div>
                            <div class='info'>
                              <h1 class='title'>Chapter Bali</h1>
                              <p class='description'>Touring pertama kita sejauh ini</p>
                              <div class="main-text-button">
                              </div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class='card card3'>
                            <div class="price"><h6>2017</h6></div>
                            <div class='info'>
                              <h1 class='title'>Chapter Jogja</h1>
                              <p class='description'>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sedii do eiusmod teme.</p>
                              <div class="main-text-button">
                              </div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class='card card4'>
                            <div class="price"><h6>2018</h6></div>
                            <div class='info'>
                              <h1 class='title'>Chapter Banten</h1>
                              <p class='description'>Ride terbaik selama ini,banyak pengalaman berharga tiap rider di perjalanannya</p>
                              <div class="main-text-button">
                              </div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class='card card5'>
                            <div class="price"><h6>2022</h6></div>
                            <div class='info'>
                              <h1 class='title'>Chapter Jakarta</h1>
                              <p class='description'>Akhirnya riding kembali setelah COVID selesai, Terbaik</p>
                              <div class="main-text-button">
                              </div>
                            </div>
                        </div>
                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** Menu Area Ends ***** -->

    <!-- ***** Chefs Area Starts ***** -->
    <div class="row">
        <div class="col-lg-12 col-md-15">
          <div class="card">
            <div class="card-header card-header-primary">
              <h4 class="card-title"><a href="admin/data_anggota.php">Data Anggota</a></h4>
            </div>
            <div class="card-body table-responsive">
              <table class="table table-hover">
                <thead class="text-warning">
                  <a href="table_index.php"></a>
                    <th>Nama</th>
                    <th>Tempat/Tanggal Lahir</th>
                    <th>Gender</th>
                    <th>Golongan Darah</th>
                    <th>Alamat</th>
                </thead>
                <tbody>
                <?php
                    foreach($db->tampil_data() as $x) {
                      ?>
                      <tr>
                        <td><?php echo $x['Nama']; ?></td>
                        <td><?php echo $x['Tempat_tanggallahir']; ?></td>
                        <td><?php echo $x['Jenis_kelamin']; ?></td>
                        <td><?php echo $x['Golongan_darah']; ?></td>
                        <td><?php echo $x['Alamat']; ?></td>         
                    </tr> <?php } ?>                      
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    
    <!-- ***** Chefs Area Ends ***** -->

    <!-- ***** Reservation Us Area Starts ***** -->
    <section class="section" id="reservation">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 align-self-center">
                    <div class="left-text-content">
                        <div class="section-heading">
                            <h6>Kontak Kami</h6>
                            <h2>Silahkan hubungi kontak dibawah ini jika ingin mengetahui lanjut tentang kami</h2>
                        </div>
                        <p>Lets Explore the world</p>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="phone">
                                    <a href="https://wa.me/6281224210167?text=I'm%20interested%20in%20your%20car%20for%20sale"><i class="fa fa-phone"></i></a>
                                    <h4>Phone Numbers</h4>
                                    <span><a href="">081224210167</a><br><a href="#">Ferdinand</a></span>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="message">
                                    <i class="fa fa-envelope"></i>
                                    <h4>Emails</h4>
                                    <span><a href="#">geranggerung@gmail.com</a></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** Reservation Area Ends ***** -->

    <!-- ***** Menu Area Starts ***** -->
    
    <!-- ***** Chefs Area Ends ***** --> 
    
    <!-- ***** Footer Start ***** -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-xs-12">
                    <div class="right-text-content">
                            <ul class="social-icons">
                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                            </ul>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="logo">
                        <a href="index.html"><img src="assets/images/geranggerung.png" alt=""></a>
                    </div>
                </div>
                <div class="col-lg-4 col-xs-12">
                    <div class="left-text-content">
                        <p>GerangGerung
                        
                        <br>Ride or Die</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- jQuery -->
    <script src="assets/js/jquery-2.1.0.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/js/popper.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Plugins -->
    <script src="assets/js/owl-carousel.js"></script>
    <script src="assets/js/accordions.js"></script>
    <script src="assets/js/datepicker.js"></script>
    <script src="assets/js/scrollreveal.min.js"></script>
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>
    <script src="assets/js/imgfix.min.js"></script> 
    <script src="assets/js/slick.js"></script> 
    <script src="assets/js/lightbox.js"></script> 
    <script src="assets/js/isotope.js"></script> 
    
    <!-- Global Init -->
    <script src="assets/js/custom.js"></script>
    <script>

        $(function() {
            var selectedClass = "";
            $("p").click(function(){
            selectedClass = $(this).attr("data-rel");
            $("#portfolio").fadeTo(50, 0.1);
                $("#portfolio div").not("."+selectedClass).fadeOut();
            setTimeout(function() {
              $("."+selectedClass).fadeIn();
              $("#portfolio").fadeTo(50, 1);
            }, 500);
                
            });
        });

    </script>
  </body>
</html>